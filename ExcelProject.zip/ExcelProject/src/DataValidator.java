import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class DataValidator {

	public static boolean Stringstarts(String name){
		
		if(Pattern.matches("[gG]{1}[a-zA-Z]{2,}",name)){
			return true;
		}
		else if(name==null)
		{
			System.out.println("Should not be null");
			return false;
		}
		else{
			System.out.println("String should start with g");
			return false;
		}
		
	}
	public static boolean Stringends(String name){
		
			if(name.endsWith("g")){
				return true;
		}
			
			else {
				System.out.println("String should end with g");
				return false;
			}
		
	}
	public static boolean Validatequals(String pass,String cnfrm) {
		if(pass.equals(cnfrm)){
		return true;
		}
		
		else{
			System.out.println("The two strings does not match");
		
		return false;
		}
	}
	public static boolean ValidatePhone(String phoneno){
		if(phoneno.matches("[0-9]{10}")){
			System.out.println("Valid Number");
			return true;
			}
			else{
				System.out.println("Enter valid number");
				return false;
			}
	}
	
	 public static boolean Validatemail(String email)
	    {
		 if(email.endsWith("com")||email.endsWith("in")){
			 System.out.println("Valid Email");
	            return true;
	        }
	        else
	        {
	        	System.out.println("Enter a valid email");
	        	return false;
	        }
	    }
	 public static boolean Validatealpha(String name) {

			Pattern p = Pattern.compile("[0-9a-zA-Z]{1,}");//. represents single character  
			Matcher m = p.matcher(name);    
			if(m.matches()){
				return true;
		}
			else
			{
				System.out.println("Address Field should not be null");
				return false;
			}
		
	}
	 public static boolean ValidateNumbers(String name) {
			
			Pattern p = Pattern.compile("[0-9]{6}");//. represents single character  
			Matcher m = p.matcher(name);    
			if(m.matches()){
				return true;
		}
		else{
			System.out.println("Pincode contains characters other than  numeric characters");
			return false;
		}
		
	}
	 public static boolean ValidateUppercase(String name) {
			
		 int length = name.length();
		 int i;
		 for(i = 0; i < length; i++) {
			 char character = name.charAt(i);
			 if(Character.isUpperCase(character)) {
		         return true;
		    }			 
		 }
		 if(i==length)
		 {
			 System.out.println("String does not contain any Upper Case letter");	 
		 }
		return false;
	
	}
	 public static boolean ValidatePass(String name){
			
			Pattern p = Pattern.compile("[a-zA-Z0-9]{4,15}");//. represents single character  
			Matcher m = p.matcher(name);    
			if(m.matches()){
				return true;
		}
			else if(name==null)
			{
				System.out.println("Should not be null");
				return false;
			}
		else{
			System.out.println("Password should contain oonly alphanumeric charcters and string length should be between 4 to 10");
			return false;
		}
		
	}
	 public static boolean ValidateCompany(String name){
			
		 if(name.matches("[a-zA-Z]{3,10}"))
			{
				
				return true;
			}
			else{
				System.out.println("Enter valid company name");
				return false;
			}
		
	}
	 public static boolean ValidateCity(String name){
			
		 if(name.matches("[a-zA-Z]{3,10}"))
			{
				
				return true;
			}
			else{
				System.out.println("Enter valid city name");
				return false;
			}
		
	}
	 public static boolean ValidatefName(String name){
			
		 if(name.matches("[a-zA-Z]{3,10}"))
			{
				
				return true;
			}
			else{
				System.out.println("Enter valid first name");
				return false;
			}
		
	}
	 public static boolean ValidatelName(String name){
			
		 if(name.matches("[a-zA-Z]{3,15}"))
			{
				
				return true;
			}
			else{
				System.out.println("Enter valid last name");
				return false;
			}
		
	}
}
