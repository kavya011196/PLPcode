import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetTextExample {

	
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","./exefiles/chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("https://www.google.co.in/");
		
		List<WebElement> e=driver.findElements(By.xpath("//div[@id='_eEe']/a"));
                System.out.println("Languages supported by Google are:");
		for(WebElement w:e)
			System.out.println(w.getText());
		
		driver.quit();
	}
}
